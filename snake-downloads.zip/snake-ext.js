/*
 * 联机贪吃蛇 —— TurboWarp / Scratch 自定义扩展（单积木版）
 *
 * 用法：TurboWarp → 添加扩展 → 自定义扩展 → 输入
 *   http://localhost:8180/snake-ext.js
 *   ★ 必须勾选「在沙盒外运行」（localhost 来源通常默认信任、自动沙盒外运行）。
 *   沙箱模式没有页面 DOM，游戏画面画不出来。
 *
 * 只有一个积木：「启动贪吃蛇」。
 * 点击后弹出全屏游戏覆盖层，先在游戏内菜单里输昵称、选速度，
 * 点「开始游戏」自动连接服务器开战。方向键/WASD 控制，空格重生，Esc 退出。
 * 画面渲染完全由本扩展自己完成，不使用 Scratch 舞台和画笔。
 */
(function (Scratch) {
  'use strict';

  const DEFAULT_URL = 'ws://localhost:8180';

  /* ============================================================
   * 内置游戏客户端（自绘画布覆盖层，零依赖）
   * ============================================================ */
  let overlay = null; // DOM 覆盖层；存在表示游戏正在运行

  function launch(name, url, speed) {
    if (overlay) return; // 防止重复启动

    // ---------- DOM ----------
    const root = document.createElement('div');
    root.style.cssText =
      'position:fixed;inset:0;z-index:999999;background:#0f172a;' +
      'font-family:system-ui,-apple-system,"PingFang SC",sans-serif;';
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;';
    const board = document.createElement('div'); // 排行榜
    board.style.cssText =
      'position:absolute;top:14px;right:14px;min-width:150px;padding:10px 14px;' +
      'background:rgba(15,23,42,.82);border:1px solid #334155;border-radius:10px;' +
      'color:#e2e8f0;font-size:14px;line-height:1.7;white-space:pre;';
    const hint = document.createElement('div'); // 底部提示
    hint.textContent = '方向键 / WASD 移动 · 空格重生 · Esc 退出';
    hint.style.cssText =
      'position:absolute;left:0;right:0;bottom:10px;text-align:center;' +
      'color:#64748b;font-size:13px;pointer-events:none;';
    root.appendChild(canvas);
    root.appendChild(board);
    root.appendChild(hint);
    document.body.appendChild(root);
    overlay = root;

    const ctx = canvas.getContext('2d');
    function resize() {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(root.clientWidth * dpr);
      canvas.height = Math.round(root.clientHeight * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener('resize', resize);

    // ---------- 网络 ----------
    let myId = 0, cols = 42, rows = 30, tickMs = 200;
    let cur = null; // 最新一帧状态 {time, data}
    let pingMs = 0, pingTimer = 0;
    let disconnected = false;
    let started = false; // 点了「开始游戏」才接管键盘
    let ws = null;

    function connect(n, spd, u) {
      try { ws = new WebSocket(u); } catch (e) { disconnected = true; return; }
      ws.onopen = () => ws.send(JSON.stringify({ t: 'join', name: n, ms: spd }));
      // 每 2 秒测一次网络往返延迟
      pingTimer = setInterval(() => {
        if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'ping', ts: Date.now() }));
      }, 2000);
      ws.onclose = () => { disconnected = true; };
      ws.onerror = () => { disconnected = true; };
      ws.onmessage = (ev) => {
        let msg;
        try { msg = JSON.parse(ev.data); } catch (e) { return; }
        if (msg.t === 'joined') {
          myId = msg.id; cols = msg.cols; rows = msg.rows; tickMs = msg.tickMs || 200;
        } else if (msg.t === 'state') {
          if (msg.tickMs) tickMs = msg.tickMs; // 别人调速时，画面节奏跟着变
          cur = { time: performance.now(), data: msg };
          // 预测校正：服务器已确认的转向移出待确认队列
          const meAck = msg.players.find(p => p.id === myId);
          if (meAck && meAck.seq) pendingTurns = pendingTurns.filter(t => t.seq > meAck.seq);
          if (!meAck || !meAck.alive) pendingTurns = [];
          renderBoard();
        } else if (msg.t === 'pong') {
          pingMs = Math.max(0, Date.now() - msg.ts);
          halfRtt = Math.min(250, pingMs / 2);
          renderBoard();
        }
      };
      frame();
    }

    // ---------- 游戏内开始菜单（昵称 + 速度，点开始就开战）----------
    const menu = document.createElement('div');
    menu.style.cssText =
      'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;' +
      'background:rgba(2,6,23,.72);';
    const panel = document.createElement('div');
    panel.style.cssText =
      'background:#1e293b;border:1px solid #334155;border-radius:14px;' +
      'padding:26px 30px;width:290px;color:#e2e8f0;box-shadow:0 20px 60px rgba(0,0,0,.5);';
    menu.appendChild(panel);

    const title = document.createElement('div');
    title.textContent = '联机贪吃蛇';
    title.style.cssText = 'font-size:22px;font-weight:700;text-align:center;margin-bottom:16px;';
    panel.appendChild(title);

    const label1 = document.createElement('div');
    label1.textContent = '昵称';
    label1.style.cssText = 'font-size:13px;color:#94a3b8;margin-bottom:6px;';
    panel.appendChild(label1);

    const nameInput = document.createElement('input');
    nameInput.maxLength = 12;
    nameInput.value = name;
    nameInput.style.cssText =
      'width:100%;box-sizing:border-box;padding:8px 10px;border-radius:8px;' +
      'border:1px solid #475569;background:#0f172a;color:#e2e8f0;font-size:14px;outline:none;';
    panel.appendChild(nameInput);

    const label2 = document.createElement('div');
    label2.textContent = '速度';
    label2.style.cssText = 'font-size:13px;color:#94a3b8;margin:14px 0 6px;';
    panel.appendChild(label2);

    const SPEEDS = [['慢速', 300], ['标准', 200], ['快速', 110], ['超快', 50]];
    let chosen = SPEEDS.some(s => s[1] === speed) ? speed : 200;
    const speedRow = document.createElement('div');
    speedRow.style.cssText = 'display:flex;gap:8px;margin-bottom:14px;';
    const speedBtns = [];
    const paintSpeeds = () => {
      for (const [b, ms] of speedBtns) {
        const on = ms === chosen;
        b.style.background = on ? '#3b82f6' : '#0f172a';
        b.style.color = on ? '#ffffff' : '#cbd5e1';
        b.style.borderColor = on ? '#3b82f6' : '#475569';
      }
    };
    for (const [text, ms] of SPEEDS) {
      const b = document.createElement('button');
      b.textContent = text;
      b.style.cssText =
        'flex:1;padding:7px 0;border-radius:8px;border:1px solid #475569;' +
        'background:#0f172a;color:#cbd5e1;font-size:14px;cursor:pointer;';
      b.onclick = () => { chosen = ms; paintSpeeds(); };
      speedBtns.push([b, ms]);
      speedRow.appendChild(b);
    }
    paintSpeeds();
    panel.appendChild(speedRow);

    const label3 = document.createElement('div');
    label3.textContent = '服务器地址（联机时填主机的局域网 IP）';
    label3.style.cssText = 'font-size:13px;color:#94a3b8;margin-bottom:6px;';
    panel.appendChild(label3);

    const urlInput = document.createElement('input');
    urlInput.value = url;
    urlInput.style.cssText = nameInput.style.cssText;
    panel.appendChild(urlInput);

    const goBtn = document.createElement('button');
    goBtn.textContent = '开始游戏';
    goBtn.style.cssText =
      'width:100%;padding:10px 0;border:none;border-radius:8px;' +
      'background:#3b82f6;color:#ffffff;font-size:16px;font-weight:600;cursor:pointer;margin-top:20px;';
    panel.appendChild(goBtn);
    root.appendChild(menu);

    function begin() {
      const n = nameInput.value.trim().slice(0, 12) || '玩家';
      const u = urlInput.value.trim() || url;
      menu.remove();
      started = true;
      connect(n, chosen, u);
    }
    goBtn.onclick = begin;
    nameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') begin(); });
    nameInput.focus();

    function send(obj) {
      if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
    }

    // ---------- 键盘 ----------
    const KEYMAP = {
      ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
      w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right'
    };
    // 本地输入预测：按键立刻画出转向（预测下一拍），服务器按 seq 确认后校正
    let inputSeq = 0;
    let pendingTurns = [];
    let halfRtt = 0;

    function sendDir(dir) {
      const me = cur && cur.data.players.find(p => p.id === myId);
      if (!me || !me.alive) return;
      const last = pendingTurns.length ? pendingTurns[pendingTurns.length - 1].dir : me.dir;
      if (dir === last || dir === { up: 'down', down: 'up', left: 'right', right: 'left' }[last]) return;
      pendingTurns.push({ seq: ++inputSeq, dir, sentAt: performance.now() });
      if (pendingTurns.length > 2) pendingTurns.shift();
      send({ t: 'dir', dir, seq: inputSeq });
    }

    function onKey(e) {
      if (e.key === 'Escape') { quit(); return; }
      if (!started) return; // 菜单开着时不接管按键（可以正常打字）
      if (e.key === ' ') { send({ t: 'respawn' }); e.preventDefault(); return; }
      const dir = KEYMAP[e.key];
      if (dir) { sendDir(dir); e.preventDefault(); }
    }
    window.addEventListener('keydown', onKey, true);

    // ---------- 排行榜 ----------
    function renderBoard() {
      const ps = cur.data.players.slice().sort((a, b) => b.score - a.score);
      let html = '延迟 ' + pingMs + 'ms\n排行榜\n';
      ps.forEach((p, i) => {
        const me = p.id === myId ? ' ◄' : '';
        html += `${i + 1}. ${p.name} ${p.score}${p.alive ? '' : ' ✕'}${me}\n`;
      });
      board.textContent = html;
    }

    // ---------- 渲染循环 ----------
    let raf = 0;
    function frame() {
      if (!overlay) return; // 已退出
      draw();
      raf = requestAnimationFrame(frame);
    }

    function draw() {
      const W = root.clientWidth, H = root.clientHeight;
      ctx.clearRect(0, 0, W, H);
      // 场地居中，格子取整数像素
      const cell = Math.max(4, Math.floor(Math.min((W - 60) / cols, (H - 60) / rows)));
      const ox = Math.round((W - cell * cols) / 2);
      const oy = Math.round((H - cell * rows) / 2);

      // 背景与边框
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 2;
      ctx.strokeRect(ox - 2, oy - 2, cell * cols + 4, cell * rows + 4);
      ctx.strokeStyle = 'rgba(148,163,184,.07)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let c = 1; c < cols; c++) { ctx.moveTo(ox + c * cell, oy); ctx.lineTo(ox + c * cell, oy + rows * cell); }
      for (let r = 1; r < rows; r++) { ctx.moveTo(ox, oy + r * cell); ctx.lineTo(ox + cols * cell, oy + r * cell); }
      ctx.stroke();

      if (!cur) {
        centerText(disconnected ? '连接失败：Esc 退出后重试，检查服务器与地址' : '连接中…', '#94a3b8');
        return;
      }

      // 外推渲染：把最新一帧朝下一格预测（pad 吸收网络抖动），消除整拍延迟
      const now = performance.now();
      const pad = Math.min(40, tickMs * 0.25);
      const frac = Math.max(0, Math.min(1, (now - cur.time - pad) / tickMs));

      const lerpSeg = (p, i, face) => {
        const b1 = p.body[i];
        const dx = { up: 0, down: 0, left: -1, right: 1 }[face || p.dir] || 0;
        const dy = { up: -1, down: 1, left: 0, right: 0 }[face || p.dir] || 0;
        const t = i === 0 ? [b1[0] + dx, b1[1] + dy] : p.body[i - 1];
        return [b1[0] + (t[0] - b1[0]) * frac, b1[1] + (t[1] - b1[1]) * frac];
      };

      const dot = (gx, gy, r, color, glow) => {
        const x = ox + (gx + 0.5) * cell, y = oy + (gy + 0.5) * cell;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        if (glow) { ctx.shadowColor = color; ctx.shadowBlur = 10; }
        ctx.fillStyle = color;
        ctx.fill();
        ctx.shadowBlur = 0;
      };

      // 食物
      for (const f of cur.data.foods) dot(f[0], f[1], cell * 0.32, '#fbbf24', true);

      // 蛇
      for (const p of cur.data.players) {
        const color = p.alive ? p.color : 'rgba(107,114,128,.45)';
        // 本地预测：自己蛇的下一拍转向立刻画出来
        let bend = null;
        if (p.id === myId && p.alive && pendingTurns.length && frac > 0) {
          const t0 = pendingTurns[0].sentAt + halfRtt;                  // 服务器约在此刻收到输入
          const kTurn = Math.ceil((t0 - (cur.time - halfRtt)) / tickMs); // 生效拍（1=下一拍）
          if (kTurn <= 1) bend = pendingTurns[0].dir;
        }
        for (let i = p.body.length - 1; i >= 0; i--) {
          const g = lerpSeg(p, i, i === 0 ? bend : null);
          dot(g[0], g[1], cell * (i === 0 ? 0.46 : 0.4), color, false);
        }
        // 蛇头眼睛（朝移动方向）
        if (p.alive && p.body.length) {
          const h = lerpSeg(p, 0);
          const hx = ox + (h[0] + 0.5) * cell, hy = oy + (h[1] + 0.5) * cell;
          const dx = { up: 0, down: 0, left: -1, right: 1 }[bend || p.dir] || 0;
          const dy = { up: -1, down: 1, left: 0, right: 0 }[bend || p.dir] || 0;
          const px = -dy, py = dx; // 垂直于朝向
          const eo = cell * 0.16, fo = cell * 0.14;
          ctx.fillStyle = '#fff';
          ctx.beginPath();
          ctx.arc(hx + dx * fo + px * eo, hy + dy * fo + py * eo, cell * 0.09, 0, Math.PI * 2);
          ctx.arc(hx + dx * fo - px * eo, hy + dy * fo - py * eo, cell * 0.09, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 中央提示
      const me = cur.data.players.find(p => p.id === myId);
      if (disconnected) centerText('已断线 · 按 Esc 退出后重新点积木', '#f87171');
      else if (me && !me.alive) centerText('按空格重生', '#fbbf24');
    }

    function centerText(text, color) {
      const W = root.clientWidth, H = root.clientHeight;
      ctx.font = '600 28px system-ui,"PingFang SC",sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(2,6,23,.55)';
      ctx.fillRect(0, H / 2 - 40, W, 80);
      ctx.fillStyle = color;
      ctx.fillText(text, W / 2, H / 2);
    }

    function quit() {
      if (!overlay) return;
      cancelAnimationFrame(raf);
      clearInterval(pingTimer);
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener('resize', resize);
      try { if (ws) ws.close(); } catch (e) { /* 忽略 */ }
      overlay.remove();
      overlay = null;
    }
  }

  /* ============================================================
   * 扩展定义：只有一个积木
   * ============================================================ */
  class SnakeNet {
    getInfo() {
      return {
        id: 'snakenet',
        name: '联机贪吃蛇',
        color1: '#3b82f6',
        color2: '#2f6bd6',
        color3: '#2454ab',
        blocks: [
          {
            blockType: Scratch.BlockType.COMMAND,
            opcode: 'startGame',
            text: '启动贪吃蛇 昵称 [NAME] 速度 [SPEED] 服务器 [URL]',
            arguments: {
              NAME: { type: Scratch.ArgumentType.STRING, defaultValue: '玩家' },
              SPEED: { type: Scratch.ArgumentType.STRING, menu: 'speeds', defaultValue: '200' },
              URL: { type: Scratch.ArgumentType.STRING, defaultValue: DEFAULT_URL }
            }
          }
        ],
        menus: {
          speeds: {
            acceptReporters: false,
            items: [
              { text: '慢速', value: '300' },
              { text: '标准', value: '200' },
              { text: '快速', value: '110' },
              { text: '超快', value: '50' }
            ]
          }
        }
      };
    }

    startGame(args) {
      const name = String(args.NAME || '玩家').slice(0, 12) || '玩家';
      const speed = Math.round(Number(args.SPEED)) || 200;
      const url = String(args.URL || DEFAULT_URL).trim() || DEFAULT_URL;
      // 沙箱模式没有 document，游戏画面无处可画，直接放弃
      //（加载本扩展时请使用「沙盒外运行」；localhost 来源 TurboWarp 默认信任）
      if (typeof document === 'undefined' || !document.body) return;
      launch(name, url, speed);
    }
  }

  Scratch.extensions.register(new SnakeNet());
})(Scratch);
