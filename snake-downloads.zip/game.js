'use strict';
/*
 * 多人贪吃蛇 —— 浏览器客户端
 * 职责：
 *   1. 用浏览器自带的 WebSocket（不用任何库）连服务器
 *   2. 只把“按键方向”发给服务器，移动/碰撞/吃食物全由服务器裁决
 *   3. 收到全员状态后用 Canvas 画出来，并在两个状态之间做插值，移动看起来平滑
 */

// ---------- DOM ----------
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const menu = document.getElementById('menu');
const deadLayer = document.getElementById('dead');
const toast = document.getElementById('toast');
const nameInput = document.getElementById('nameInput');
const joinBtn = document.getElementById('joinBtn');
const respawnBtn = document.getElementById('respawnBtn');
const myScoreEl = document.getElementById('myScore');
const onlineEl = document.getElementById('online');
const rankList = document.getElementById('rankList');
const deadReasonEl = document.getElementById('deadReason');
const deadScoreEl = document.getElementById('deadScore');
const menuError = document.getElementById('menuError');
const serverInput = document.getElementById('serverInput');
const serverAddrEl = document.getElementById('serverAddr');

// ---------- 服务器地址 ----------
// 页面由游戏服务器直接提供时（localhost / ts.net），默认连自己；
// 页面托管在静态平台（如 workers.dev）时，默认连 Tailscale 公网入口。
const FALLBACK_SERVER = 'wss://niesdemacbook-air.tail4f9990.ts.net';

function defaultWsUrl() {
  // 打包环境（DMG/EXE/APK/IPA 壳里是 file:// 或自定义协议）没有同源服务器，
  // 默认连主人分享的公网入口；网页环境连自己。
  // EXE 壳用虚拟主机 app.htmlpack 加载，也没有同源服务器
  if (!/^https?:$/.test(location.protocol) || location.hostname === 'app.htmlpack') return FALLBACK_SERVER;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  return proto + '://' + location.host;
}

function normalizeWs(v) {
  v = String(v || '').trim().replace(/\/+$/, '');
  if (!v) return '';
  if (!/^wss?:\/\//i.test(v)) {
    v = (location.protocol === 'https:' ? 'wss://' : 'ws://') + v;
  }
  return v;
}

let wsUrl = localStorage.getItem('snakeServer')
  || (/(^|\.)workers\.dev$/.test(location.hostname) ? FALLBACK_SERVER : defaultWsUrl());

function updateServerLabel() {
  serverAddrEl.textContent = '服务器：' + wsUrl.replace(/^wss?:\/\//, '');
}

serverInput.value = wsUrl;
updateServerLabel();

// ---------- 延迟测量 ----------
const pingEl = document.getElementById('ping');
setInterval(() => {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'ping', ts: Date.now() }));
}, 2000);

// ---------- 常量 / 状态 ----------
const CELL = 20;                 // 每格像素（画布 42*20 x 30*20 = 840x600）
let COLS = 42, ROWS = 30, TICK_MS = 200;

let ws = null;
let myId = null;
let myName = localStorage.getItem('snakeName') || '';
let joined = false;
let hasJoined = false;   // 本轮连接是否成功进过房（区分"连不上"与"中途断线"）
let deadShown = false;

// 最新两帧快照，用于插值：渲染位置 = lerp(prev, cur, alpha)
let prevSnap = null;
let curSnap = null;
let curAt = 0;
let reconnectTimer = null;

nameInput.value = myName;

// ---------- 速度选择（登录页三档，加入时告诉服务器，全局生效）----------
const speedRow = document.getElementById('speedRow');
let chosenMs = 200;
speedRow.addEventListener('click', e => {
  const btn = e.target.closest('.speed-btn');
  if (!btn) return;
  chosenMs = Number(btn.dataset.ms) || 200;
  for (const b of speedRow.querySelectorAll('.speed-btn')) {
    b.classList.toggle('active', b === btn);
  }
});

// ---------- 网络 ----------
function connect() {
  hasJoined = false;
  ws = new WebSocket(wsUrl);

  ws.onopen = () => {
    hideToast();
    if (joined) {
      // 断线重连后重新报到，服务器会分配新蛇
      ws.send(JSON.stringify({ t: 'join', name: myName, ms: chosenMs }));
    }
  };

  ws.onmessage = ev => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }

    if (msg.t === 'joined') {
      myId = msg.id;
      hasJoined = true;
      COLS = msg.cols; ROWS = msg.rows; TICK_MS = msg.tickMs;
    } else if (msg.t === 'state') {
      if (msg.tickMs) TICK_MS = msg.tickMs; // 有人中途调速时，插值节奏跟着变
      prevSnap = curSnap;
      curSnap = msg;
      curAt = performance.now();
      // 预测校正：服务器已确认的转向移出待确认队列
      const meAck = msg.players.find(p => p.id === myId);
      if (meAck && meAck.seq) pendingTurns = pendingTurns.filter(t => t.seq > meAck.seq);
      if (!meAck || !meAck.alive) pendingTurns = [];
      // 第一次收到状态时，prev 直接等于 cur，避免从 (0,0) 飞过来
      if (!prevSnap) prevSnap = msg;
      updateHUD();
    } else if (msg.t === 'sys') {
      menuError.textContent = msg.msg;
    } else if (msg.t === 'pong') {
      halfRtt = Math.min(250, Math.max(0, Date.now() - msg.ts) / 2);
      pingEl.textContent = '延迟 ' + Math.round(halfRtt * 2) + 'ms';
    }
  };

  ws.onclose = () => {
    curSnap = null; prevSnap = null;
    if (joined && !hasJoined) {
      // 从未成功进房：地址填错或服务器没开，回到菜单让用户修正
      joined = false;
      clearTimeout(reconnectTimer);
      menu.classList.remove('hidden');
      menuError.textContent = '连不上 ' + wsUrl.replace(/^wss?:\/\//, '') + '，检查地址或服务器是否在运行';
      return;
    }
    if (joined) {
      showToast('连接断开，正在重连…');
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connect, 1200);
    }
  };

  ws.onerror = () => { try { ws.close(); } catch {} };
}

function send(obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

joinBtn.addEventListener('click', joinGame);
nameInput.addEventListener('keydown', e => { if (e.key === 'Enter') joinGame(); });

function joinGame() {
  myName = nameInput.value.trim().slice(0, 12) || ('玩家' + (Math.random() * 900 + 100 | 0));
  localStorage.setItem('snakeName', myName);
  joined = true;
  menuError.textContent = '';
  // 用户改过服务器地址：切换目标并重连
  const entered = normalizeWs(serverInput.value);
  if (entered && entered !== wsUrl) {
    wsUrl = entered;
    localStorage.setItem('snakeServer', wsUrl);
    updateServerLabel();
    if (ws) { try { ws.onclose = null; ws.close(); } catch {} ws = null; }
  }
  if (!ws || ws.readyState === 3) connect();
  send({ t: 'join', name: myName, ms: chosenMs });
  menu.classList.add('hidden');
}

respawnBtn.addEventListener('click', () => send({ t: 'respawn' }));

// ---------- 输入：键盘 ----------
const KEY_DIR = {
  ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
  w: 'up', s: 'down', a: 'left', d: 'right',
  W: 'up', S: 'down', A: 'left', D: 'right'
};

// ---------- 本地输入预测 ----------
// 按键立刻画出转向（预测下一拍），服务器状态到达后按 seq 自动校正
let inputSeq = 0;
let pendingTurns = [];   // 已发送未确认的转向 [{seq, dir, sentAt}]
let halfRtt = 0;         // 单程延迟估计（ping RTT 的一半）

function sendDir(dir) {
  const me = curSnap && curSnap.players.find(p => p.id === myId);
  if (!me || !me.alive) return;
  const last = pendingTurns.length ? pendingTurns[pendingTurns.length - 1].dir : me.dir;
  if (dir === last || dir === { up: 'down', down: 'up', left: 'right', right: 'left' }[last]) return;
  pendingTurns.push({ seq: ++inputSeq, dir, sentAt: performance.now() });
  if (pendingTurns.length > 2) pendingTurns.shift();   // 与服务器 INPUT_BUFFER 一致
  send({ t: 'dir', dir, seq: inputSeq });
}

window.addEventListener('keydown', e => {
  if (!joined) return;
  const dir = KEY_DIR[e.key];
  if (dir) {
    e.preventDefault();                 // 防止方向键滚动页面
    if (!e.repeat) sendDir(dir);
  } else if (e.key === ' ') {
    e.preventDefault();
    const me = curSnap && curSnap.players.find(p => p.id === myId);
    if (me && !me.alive) send({ t: 'respawn' });
  }
});

// ---------- 输入：手机滑动 ----------
let touchStart = null;
canvas.addEventListener('touchstart', e => {
  const t = e.touches[0];
  touchStart = { x: t.clientX, y: t.clientY };
}, { passive: true });

canvas.addEventListener('touchmove', e => {
  if (!touchStart) return;
  const t = e.touches[0];
  const dx = t.clientX - touchStart.x;
  const dy = t.clientY - touchStart.y;
  if (Math.abs(dx) < 24 && Math.abs(dy) < 24) return; // 滑动距离太短不算
  sendDir(Math.abs(dx) > Math.abs(dy)
    ? (dx > 0 ? 'right' : 'left')
    : (dy > 0 ? 'down' : 'up'));
  touchStart = { x: t.clientX, y: t.clientY };      // 以当前点为新起点，可连续拐弯
}, { passive: true });

// ---------- HUD / 排行榜 ----------
function myPlayer() {
  return curSnap && curSnap.players.find(p => p.id === myId);
}

function updateHUD() {
  const me = myPlayer();
  onlineEl.textContent = '在线 ' + curSnap.players.length + ' 人';
  myScoreEl.textContent = '得分 ' + (me ? me.score : 0);

  // 死亡覆盖层
  if (me && !me.alive) {
    if (!deadShown) {
      deadShown = true;
      deadReasonEl.textContent = me.deathReason || '';
      deadScoreEl.textContent = me.score;
      deadLayer.classList.remove('hidden');
    }
  } else if (me && me.alive) {
    deadShown = false;
    deadLayer.classList.add('hidden');
  }

  // 排行榜（分数降序，同分按 id）
  const ranked = [...curSnap.players].sort((a, b) => b.score - a.score || a.id - b.id);
  rankList.innerHTML = ranked.map((p, i) => `
    <li class="${p.id === myId ? 'me' : ''} top${i + 1}">
      <span class="rk">${i + 1}</span>
      <span class="dot ${p.alive ? '' : 'dead'}" style="background:${p.color}"></span>
      <span class="nm ${p.alive ? '' : 'dead'}">${escapeHTML(p.name)}</span>
      <span class="sc">${p.score}</span>
    </li>`).join('');
}

function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function showToast(t) { toast.textContent = t; toast.classList.remove('hidden'); }
function hideToast() { toast.classList.add('hidden'); }

// ---------- 渲染 ----------
function lerp(a, b, t) { return a + (b - a) * t; }

function drawBoard() {
  ctx.fillStyle = '#11152a';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  // 棋盘格
  ctx.fillStyle = 'rgba(255,255,255,0.025)';
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      if ((x + y) % 2 === 0) ctx.fillRect(x * CELL, y * CELL, CELL, CELL);
    }
  }
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.fill();
}

function drawFoods(snap, alpha) {
  for (const [fx, fy] of snap.foods) {
    const cx = fx * CELL + CELL / 2, cy = fy * CELL + CELL / 2;
    const pulse = 1 + Math.sin(performance.now() / 250 + fx) * 0.08; // 呼吸感
    ctx.fillStyle = '#ff5d8f';
    ctx.beginPath();
    ctx.arc(cx, cy, CELL * 0.36 * pulse, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.55)';
    ctx.beginPath();
    ctx.arc(cx - 3, cy - 3, 2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawSnake(p, frac, bend) {
  if (!p.alive || p.body.length === 0) return;
  const body = p.body;
  const face = bend || p.dir; // bend = 本地预测的下一拍转向
  const dv = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] }[face] || [1, 0];
  const pts = body.map((seg, i) => {
    // 外推：每节朝前一节的位置移动；蛇头朝当前方向预测下一格
    const t = i === 0 ? [seg[0] + dv[0], seg[1] + dv[1]] : body[i - 1];
    return { x: (seg[0] + (t[0] - seg[0]) * frac) * CELL, y: (seg[1] + (t[1] - seg[1]) * frac) * CELL };
  });

  // 身体：从尾画到头，头在最上层
  for (let i = pts.length - 1; i >= 0; i--) {
    const s = pts[i];
    const t = i / Math.max(pts.length - 1, 1);
    ctx.fillStyle = p.color;
    ctx.globalAlpha = lerp(0.55, 1, 1 - t);  // 尾巴半透明，有渐变感
    const pad = i === 0 ? 1 : 2;
    roundRect(s.x + pad, s.y + pad, CELL - pad * 2, CELL - pad * 2, 6);
  }
  ctx.globalAlpha = 1;

  // 蛇头眼睛（根据朝向）
  const h = pts[0];
  const d = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] }[face] || [1, 0];
  const cx = h.x + CELL / 2, cy = h.y + CELL / 2;
  const side = { x: -d[1], y: d[0] }; // 垂直于朝向
  ctx.fillStyle = '#fff';
  for (const sgn of [-1, 1]) {
    const ex = cx + d[0] * 4 + side.x * 4 * sgn;
    const ey = cy + d[1] * 4 + side.y * 4 * sgn;
    ctx.beginPath();
    ctx.arc(ex, ey, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#111';
    ctx.beginPath();
    ctx.arc(ex + d[0] * 1.2, ey + d[1] * 1.2, 1.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fff';
  }

  // 自己的蛇头上加昵称，方便在混战中找到自己
  if (p.id === myId) {
    ctx.fillStyle = 'rgba(255,255,255,.9)';
    ctx.font = 'bold 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('你', h.x + CELL / 2, h.y - 3);
  }
}

let lastRaf = 0;
function render(now) {
  requestAnimationFrame(render);
  drawBoard();
  if (!curSnap) return;

  // 外推渲染：把最新一帧朝下一格预测（pad 吸收网络抖动），消除整拍延迟
  const pad = Math.min(40, TICK_MS * 0.25);
  const frac = Math.max(0, Math.min(1, (now - curAt - pad) / TICK_MS));

  drawFoods(curSnap);

  for (const p of curSnap.players) {
    // 本地预测：自己蛇的下一拍转向立刻画出来，服务器状态到达后自动校正
    let bend = null;
    if (p.id === myId && p.alive && pendingTurns.length && frac > 0) {
      const t0 = pendingTurns[0].sentAt + halfRtt;                  // 服务器约在此刻收到输入
      const kTurn = Math.ceil((t0 - (curAt - halfRtt)) / TICK_MS);  // 生效拍（1=下一拍）
      if (kTurn <= 1) bend = pendingTurns[0].dir;
    }
    drawSnake(p, frac, bend);
  }
}

// ---------- 启动 ----------
connect();           // 进页面就先连上，这样“在线人数”菜单阶段也能看到（不发 join 不计入玩家）
requestAnimationFrame(render);
