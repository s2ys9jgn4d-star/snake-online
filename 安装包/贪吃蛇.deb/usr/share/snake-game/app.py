#!/usr/bin/env python3
"""贪吃蛇 Linux 客户端：Qt WebEngine 原生窗口，加载公网网页版。"""
import sys
import subprocess

URL = "https://snake-downloads.pages.dev/play.html"
ICON = "/usr/share/icons/hicolor/256x256/apps/snake-game.png"

try:
    from PyQt5.QtCore import QUrl
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtGui import QIcon
    from PyQt5.QtWebEngineWidgets import QWebEngineView
except ImportError:
    # 依赖没装（不该发生，deb 里有 Depends），退回浏览器
    subprocess.Popen(["xdg-open", URL],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    sys.exit(0)

app = QApplication(sys.argv)
app.setApplicationName("snake-game")
app.setDesktopFileName("snake-game")

win = QWebEngineView()
win.setWindowTitle("贪吃蛇")
win.setWindowIcon(QIcon(ICON))
win.resize(1152, 760)
win.load(QUrl(URL))
win.show()
sys.exit(app.exec_())
